# Tests

Run the tests with nodeunit. Get nodeunit by executing

```
npm install -g nodeunit
```

then run the sanity tests with

```
nodeunit test/sanity/kmeans
nodeunit test/sanity/hcluster
```
